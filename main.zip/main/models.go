package main

type Product struct {
	Id          string
	ProductCode string
	ProductName string
}

type Category struct {
	Id           string
	CategoryName string
}
